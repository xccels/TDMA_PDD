#include <stdio.h>
#include <stdint.h>

#include <library_types.h>

#ifndef __cplusplus
typedef enum cudaDataType_t cudaDataType_t;
#endif

#include <cuda_runtime.h>
#include <cuComplex.h>
#include <cutensor.h>

#define CHECK_CUDA(call)                                           \
    do {                                                           \
        cudaError_t err = (call);                                  \
        if (err != cudaSuccess) {                                  \
            fprintf(stderr, "CUDA error %s:%d: %s\n",              \
                    __FILE__, __LINE__, cudaGetErrorString(err));  \
            return -1;                                             \
        }                                                          \
    } while (0)

#define CHECK_CUTENSOR(call)                                       \
    do {                                                           \
        cutensorStatus_t err = (call);                             \
        if (err != CUTENSOR_STATUS_SUCCESS) {                      \
            fprintf(stderr, "cuTENSOR error %s:%d: %s\n",          \
                    __FILE__, __LINE__, cutensorGetErrorString(err)); \
            return -2;                                             \
        }                                                          \
    } while (0)

/*
   Complex double transpose:

      A(k,i,j) -> B(j,i,k)

   Fortran side:

      complex(8), device :: A(nk,ni,nj)
      complex(8), device :: B(nj,ni,nk)

   Mathematical mapping:

      B(j,i,k) = A(k,i,j)

   stream_ptr must be a cudaStream_t value passed as c_ptr from Fortran.
*/
int cutensor_transpose_kij_to_jik_d_stream(
    const double *A,
    double *B,
    int64_t nk,
    int64_t ni,
    int64_t nj,
	 cudaStream_t stream
)
{
    cutensorHandle_t handle;
    cutensorTensorDescriptor_t descA;
    cutensorTensorDescriptor_t descB;

    const uint32_t numModes = 3;

    int64_t extentA[3] = {nk, ni, nj};
    int64_t strideA[3] = {1, nk, nk * ni};
    int32_t modeA[3]   = {'k', 'i', 'j'};

    int64_t extentB[3] = {nj, ni, nk};
    int64_t strideB[3] = {1, nj, nj * ni};
    int32_t modeB[3]   = {'j', 'i', 'k'};

	 double alpha = 1.0;


    CHECK_CUTENSOR(cutensorInit(&handle));

    CHECK_CUTENSOR(cutensorInitTensorDescriptor(
        &handle,
        &descA,
        numModes,
        extentA,
        strideA,
        CUDA_R_64F,
        CUTENSOR_OP_IDENTITY
    ));

    CHECK_CUTENSOR(cutensorInitTensorDescriptor(
        &handle,
        &descB,
        numModes,
        extentB,
        strideB,
        CUDA_R_64F,
        CUTENSOR_OP_IDENTITY
    ));

    CHECK_CUTENSOR(cutensorPermutation(
        &handle,
        &alpha,
        A,
        &descA,
        modeA,
        B,
        &descB,
        modeB,
        CUDA_R_64F,
        stream
    ));

    CHECK_CUDA(cudaGetLastError());
}
